---
name: waydroid
description: Use when managing Waydroid, GAPPS, Weston, and networking.
---

# Waydroid Management & Troubleshooting

## Trigger Conditions
Use this skill when setting up Waydroid, adding Google Play Store support, running Waydroid on X11 or hybrid graphics with Weston, or resolving network connectivity and DHCP routing issues.

## 1. Google Play Store (GAPPS) Integration
- **Method 1 (Preserve Data):** Use `waydroid_script` (`github.com/casualsnek/waydroid_script`):
  ```bash
  waydroid session stop
  sudo systemctl stop waydroid
  git clone https://github.com/casualsnek/waydroid_script.git && cd waydroid_script
  python3 -m venv venv && source venv/bin/activate && pip install -r requirements.txt
  sudo python3 main.py gapps
  ```
- **Method 2 (Fresh Container):**
  ```bash
  sudo waydroid init -f -s GAPPS
  ```
- **Device Uncertified Fix:** If Google Play Store says the device is uncertified, register the 16-digit Android ID at [android.com/uncertified](https://www.google.com/android/uncertified).

## 2. Running on X11 & Hybrid Graphics (Weston)
If Waydroid fails to show UI or hangs on non-Wayland desktop sessions:
```bash
sudo waydroid container start
pkill -f weston 2>/dev/null || true
weston --use-pixman &
sleep 4
export WAYLAND_DISPLAY=$(ls /run/user/1000/wayland-* 2>/dev/null | grep -o 'wayland-[0-9]*' | tail -n 1)
waydroid session start &
# Wait for RUNNING status, then show UI
waydroid show-full-ui &
```

## 3. Network & DHCP Routing Fixes
If Waydroid has no internet connection:
1. **UFW Firewall Rule:**
   ```bash
   sudo ufw allow in on waydroid0
   ```
2. **IP Routing / DHCP Table Fix (Automated in Launcher Script):**
   ```bash
   sleep 8
   sudo waydroid shell -- ip route add 192.168.240.0/24 dev eth0 table eth0 2>/dev/null
   sudo waydroid shell -- ip route add default via 192.168.240.1 dev eth0 table eth0 2>/dev/null
   ```

## Pitfalls
- **DHCP Delay:** Android inside Waydroid takes several seconds to acquire an IP via DHCP; routing commands must wait (`sleep 8`) before being applied.
- **Graphics Backend:** Always use `--use-pixman` with Weston if experiencing black screens on hybrid Intel/NVIDIA laptops.
