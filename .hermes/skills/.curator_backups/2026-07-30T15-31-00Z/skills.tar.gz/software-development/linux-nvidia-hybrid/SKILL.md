---
name: linux-nvidia-hybrid
description: Use when troubleshooting or configuring NVIDIA and Intel hybrid graphics on Linux, external display freezing, power management, and DRM modeset.
---

# Linux NVIDIA Hybrid Graphics & Display Troubleshooting

## Overview
Procedures and fixes for managing NVIDIA and Intel hybrid graphics laptops on Linux, specifically addressing external monitor freezes, power management, and kernel modesetting.

## Key Configurations

### 1. External Display Freezing / NVIDIA Power Management
External monitors connected to NVIDIA ports on hybrid laptops can freeze due to aggressive runtime power management (D3Cold / Dynamic Power Management).
- Check or create `/etc/modprobe.d/nvidia-pm.conf`:
  ```text
  options nvidia NVreg_DynamicPowerManagement=0x00
  ```

### 2. DRM Modeset in GRUB
To prevent desynchronization and ensure proper display handling with NVIDIA proprietary drivers:
- Edit `/etc/default/grub` and ensure `nvidia-drm.modeset=1` is passed in `GRUB_CMDLINE_LINUX_DEFAULT`:
  ```text
  GRUB_CMDLINE_LINUX_DEFAULT="quiet nvidia-drm.modeset=1"
  ```
- Update GRUB:
  ```bash
  sudo update-grub
  ```
