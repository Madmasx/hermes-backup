---
name: linux-desktop-customization
description: Use when configuring Linux desktop shortcuts and gsettings.
---

# Linux Desktop Customization

## Trigger Conditions
- User wants to configure keyboard shortcuts, keybindings, or desktop utility behavior on Linux (GNOME, etc.).
- Automating desktop preference configuration via command-line tools.

## Key Procedures (GNOME / gsettings)

### 1. Managing Custom Keybindings
- List custom keybindings:
  `gsettings get org.gnome.settings-daemon.plugins.media-keys custom-keybindings`
- Add a custom keybinding (e.g., custom1):
  1. Update array of paths:
     `gsettings set org.gnome.settings-daemon.plugins.media-keys custom-keybindings "['/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom0/', '/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom1/']"`
  2. Set name, command, and binding:
     `gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom1/ name 'Name'`
     `gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom1/ command 'command-to-run'`
     `gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom1/ binding 'Print'`

### 2. Disabling Conflicting Built-in Shortcuts
- Clear built-in keybindings (e.g., default screenshot UI):
  `gsettings set org.gnome.shell.keybindings show-screenshot-ui "['']"`

### 3. Flameshot QR Code Scanning Integration
- Install `zbar-tools` (`sudo apt install zbar-tools`).
- Create a helper script to scan QR selections on screen:
  ```bash
  #!/bin/bash
  RESULT=$(flameshot gui --raw | zbarimg -q - 2>/dev/null)
  if [ -n "$RESULT" ]; then
      CONTENT=$(echo "$RESULT" | sed 's/^[^:]*://')
      echo -n "$CONTENT" | xclip -selection clipboard
      notify-send "QR Escaneado con Éxito" "$CONTENT\n(Copiado al portapapeles)"
  else
      notify-send "Escáner QR" "No se detectó ningún código QR en la selección."
  fi
  ```
- Register it as a custom keybinding (e.g. `<Shift>Print`) and/or create a `.desktop` launcher in `~/.local/share/applications/` so it appears in the app menu.

## Pitfalls
- Always check existing custom-keybinding indices (custom0, custom1, etc.) before overwriting to avoid breaking user's other shortcuts.
- **Flameshot on X11 / Browsers:** 
  - Requires `xclip` package installed (`sudo apt install xclip`) to copy images to the clipboard.
  - Browser/WhatsApp Web clipboard paste issues: set `useJpgForClipboard=false` in `~/.config/flameshot/flameshot.ini` so images are copied as PNG rather than JPEG, ensuring compatibility with web apps and messaging clients.
