---
name: linux-audio-troubleshooting
description: Use when fixing PipeWire audio crackling or USB glitches.
---

# Linux Audio Troubleshooting (PipeWire & USB Headsets)

## Overview
Procedures for fixing audio crackling, static, or short-circuit artifacts on startup in Linux caused by PipeWire sample rate mismatch or dynamic buffer renegotiation on USB/Type-C audio devices.

## PipeWire Clock & Quantum Fix for USB Headsets
When USB or Type-C audio devices crackle or produce static on startup due to buffer renegotiation:
1. Create user configuration directory:
   ```bash
   mkdir -p ~/.config/pipewire
   cp /usr/share/pipewire/pipewire.conf ~/.config/pipewire/
   ```
2. Set fixed clock rates and quantum in `~/.config/pipewire/pipewire.conf`:
   ```text
   default.clock.rate          = 48000
   default.clock.allowed-rates = [ 48000 ]
   default.clock.quantum       = 512
   default.clock.min-quantum   = 512
   default.clock.max-quantum   = 1024
   ```
3. Restart user services:
   ```bash
   systemctl --user restart pipewire wireplumber pipewire-pulse
   ```
